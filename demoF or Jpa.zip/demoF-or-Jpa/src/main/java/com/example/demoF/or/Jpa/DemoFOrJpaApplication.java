package com.example.demoF.or.Jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoFOrJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoFOrJpaApplication.class, args);
	}

}
