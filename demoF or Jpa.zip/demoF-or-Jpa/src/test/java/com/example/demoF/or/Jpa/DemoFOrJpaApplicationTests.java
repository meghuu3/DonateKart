package com.example.demoF.or.Jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoFOrJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
