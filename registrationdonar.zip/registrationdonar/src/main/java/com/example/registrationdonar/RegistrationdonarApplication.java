package com.example.registrationdonar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistrationdonarApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistrationdonarApplication.class, args);
	}

}
