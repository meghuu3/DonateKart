package com.example.registrationdonar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationdonarApplicationTests {

	@Test
	void contextLoads() {
	}

}
